from django.shortcuts import render

# Create your views here.

#aqui van todas las funciones  de nuestra pagina
def home(request):
    return render(request,'PaginaCompleta/index.html')

def nosotros(request):
    return render(request,'PaginaCompleta/nosotros.html')

def blog(request):
    return render(request,'PaginaCompleta/blog.html')
 
def contact(request):
    return render(request,'PaginaCompleta/contact.html')

def contacto(request):
    return render(request,'PaginaCompleta/contacto.html')

def conversor_moneda(request):
    return render(request,'PaginaCompleta/conversor_moneda.html')

def enviado(request):
    return render(request,'PaginaCompleta/enviado.html')

def shop(request):
    return render(request,'PaginaCompleta/shop.html')

